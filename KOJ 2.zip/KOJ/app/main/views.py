from flask import render_template, redirect, url_for, abort, flash, request,\
    current_app, make_response, jsonify
from flask.wrappers import Response
from . import main
from .. import db
from ..models import State, Room, User, Regist
from flask_login import current_user, login_required
import json, time
from .forms import CodeForm, SourceForm
import subprocess
import time
import os.path
from sys import stderr

@main.route('/', methods = ['GET', 'POST'])
def index():

    code = "#include <stdio.h>\n\nint main()\n{\n\n\treturn 0;\n}"

    if request.method == 'POST':
        print(request.form['code']+"bbbb")
        mode = ['c']
        filepath = "/home/KOJ/file/"
        cfilename = filepath + mode[0] + "file.c"
        file = open(cfilename, "wb")
        file.write(request.form['code'].encode('utf-8'))
        file.close()

        txtfilename = filepath + "input.txt" 
        file = open(txtfilename, "w+", encoding='utf-8')
        file.write(request.form['input'])
        file.close()

        command = "gcc -o " + filepath + "/file " +  cfilename # 컴파일 명령

        result1 = subprocess.run(command.split(' '), stdout=subprocess.PIPE, stderr=subprocess.PIPE) # 컴파일

        command = filepath + "file" # 실행 명령

        path = open(txtfilename) # 입력 코드 파일

        result2 = subprocess.run(command, stdin=path, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True, encoding = 'utf-8') # 실행

        out = ""

        if result1.stderr == b'': # 컴파일 잘됨
            if result2.returncode == 0: # 실행 잘됨
                print("1")
                print("정답")
                out = result2.stdout
            else: # 실행 안됨
                print("2")
                print("틀렸습니다")
                out = result2.stderr
        else: # 컴파일 안됨
            print("3")
            print("틀렸습니다")
            out = result1.stderr.decode('utf-8')

        code = request.form['code']
        input = request.form['input']
        return render_template('main/1st.html', output=out, code=code, input=input)

    return render_template('main/1st.html', code=code)